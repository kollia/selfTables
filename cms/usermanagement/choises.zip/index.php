<?php


		require_once("head.php");
//Tag::debug(true);	
		//$user->hasAccess("meddocsUser"); // f�r Zgriffs-Benutztung
		$user->hasUserManagementAccess(null, true); // nur f�r UserMangement
		
			//f�r <HEAD>
			$title= "UserManagement";
			$head= makeHead($title);
				$head->add(getCssLink($default_css_link));
			//f�r <BODY>
			$backAddress= null;
			$defaultBodyHead= getDefaultBodyHead($backAddress);
			$defaultBodyFoot= getDefaultBodyFoot();
			
		// erzeuge Liste von erlaubten Projekten
		$aProjects= array();
		$statement ="select ID,Name,Description from MUProject";
		$projects= $UserDb->fetch_array($statement);
		//st_print_r($projects,2);
		foreach($projects as $row)
		{
			if($user->hasUserManagementAccess($projectId))
			{
				$project= array();
				$project["id"]= $row[0];
				$project["name"]= $row[1];
				$project["description"]= $row[2];
				$aProjects[]= $project;
			}
		}
		if(count($aProjects)==1)
		{
			$project= reset($aProjects);
			header("Location: list.php?onlyOne&table=MUUserGroup&project=".$project["id"]);
			exit();
		}
		// erzeuge Tabelle mit Projekten
		$projectTable= new TableTag();
		if($user->hasAccess("UM_createUser"))
		{//echo "has UM_createUser Access<br />";
   // --  User erstellen  --------------------------------------------------------------------------------
			$tr= new RowTag();
				$td= new ColumnTag(TD);
					$td->align("right");
					$b= new BTag();
						$b->add("User:");
					$td->add($b);
				$tr->add($td);
				$td= new ColumnTag(TD);
					$td->align("right");
					$button= new ButtonTag();
						$button->type($button);
						$button->onClick("javascript:self.location.href='make.php?action=insert&table=MUUser'");
						$button->add("erstellen");
					$td->add($button);
				$tr->add($td);
				$td= new ColumnTag(TD);
					$td->align("left");
					$button= new ButtonTag();
						$button->type($button);
						$button->onClick("javascript:self.location.href='list.php?table=MUUser'");
						$button->add("aktualisieren/l�schen");
					$td->add($button);
				$tr->add($td);
			$projectTable->add($tr);
		}
		if($user->hasAccess("allAdmin"))
		{//echo "has allAdmin access<br />";
   // --  Projekt erstellen  --------------------------------------------------------------------------------
			$tr= new RowTag();
				$td= new ColumnTag(TD);
					$td->align("right");
					$b= new BTag();
						$b->add("Project:");
					$td->add($b);
				$tr->add($td);
				$td= new ColumnTag(TD);
					$td->align("right");
					$button= new ButtonTag();
						$button->type($button);
						$button->onClick("javascript:self.location.href='make.php?action=insert&table=MUProject'");
						$button->add("erstellen");
					$td->add($button);
				$tr->add($td);
				$td= new ColumnTag(TD);
					$td->align("left");
					$button= new ButtonTag();
						$button->type($button);
						$button->onClick("javascript:self.location.href='list.php?table=MUProject'");
						$button->add("aktualisieren/l�schen");
					$td->add($button);
				$tr->add($td);
			$projectTable->add($tr);
		}
		if($user->hasAccess("allAdmin"))
		{//echo "has allAdmin access<br />";
   // --  Gruppen erstellen  --------------------------------------------------------------------------------
			$tr= new RowTag();
				$td= new ColumnTag(TD);
					$td->align("right");
					$b= new BTag();
						$b->add("Groups:");
					$td->add($b);
				$tr->add($td);
				$td= new ColumnTag(TD);
					$td->align("right");
					$button= new ButtonTag();
						$button->type($button);
						$button->onClick("javascript:self.location.href='make.php?action=insert&table=MUGroup'");
						$button->add("erstellen");
					$td->add($button);
				$tr->add($td);
				$td= new ColumnTag(TD);
					$td->align("left");
					$button= new ButtonTag();
						$button->type($button);
						$button->onClick("javascript:self.location.href='list.php?table=MUGroup'");
						$button->add("aktualisieren/l�schen");
					$td->add($button);
				$tr->add($td);
			$projectTable->add($tr);
		}
			$tr= new RowTag();
				$th= new ColumnTag(TH);
					$th->add(br());
					$th->add("project specific settings");
				$tr->add($th);
			$projectTable->add($tr);
		
    if($user->hasAccess("allAdmin") || $Name=="UserManagement")
    	$address= "javascript:self.location.href='choises.php?project=";
    else
    	$address= "javascript:self.location.href='list.php?table=MUUserGroup&project=";
		foreach($aProjects as $project)
		{
			$tr= new RowTag();
				$td= new ColumnTag(TD);
					$td->colspan(3);
					$a= new ATag();
						$a->href($address.$project["id"]."'");
						$a->add($project["name"]);
					$td->add($a);
					$td->add(br());
					$td->add($project["description"]);
				$tr->add($td);
			$projectTable->add($tr);
		}//st_print_r($projectTable->inherit[0]->inherit[0],2);
?>
<html>
		<? $head->display() ?>
		<body>
			<? $defaultBodyHead->display() ?>
			<br><br><br><br><br>
			<center>
				<h1><em>Projekt</em> UserManagement</h1>
				<? $projectTable->display(); ?>
<!---
				<table border="1">
					<tr>
						<th align="center">
							Projekt-Auswahl
						</th>
					</tr>
					<? foreach($aProjects as $Name=>$ID) ?>
					<? { echo "do Row $Name<br />"; ?>
						<tr>
							<td>
								<input type="button" value="<? $Name ?>"
										onClick="javascript:self.location.href='choises.php?ID=<? echo $ID ?>'" />
							</td>
						</tr>
					<? } ?>
				</table>	
											//--->	
			</center>
			<? $defaultBodyFoot->display() ?>
		</body>		
</html>