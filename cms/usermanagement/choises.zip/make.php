<?php


		require_once("head.php");
		require_once($insert_update);
		
		 
		 	$tableName= $HTTP_GET_VARS["table"];
			$action= $HTTP_GET_VARS["action"];
			$projectID= $HTTP_GET_VARS["project"];
			if(preg_match("/^aktualisieren/", $action))
				$action= "aktualisieren";
				
		 	// erstelle Tabelle MUSBox mit Datenbank-Zugriffen
			$MUSBox= new MUSBox($UserDb);
			$MUSBox->table($tableName);
			// deffiniere <HEAD> mit allen Scripting-Tags
			// sowie JavaScripts f�r den <BODY>
			$title= "UserManagement";
			$head= makeHead($title);
				$head->add($MUSBox->getCssLink());
			//f�r <BODY>
		if($projectID)
		{
			if($action=="insert")
				$backAddress= "choises.php?";
			else
				$backAddress= "list.php?table=$tableName&";
			$backAddress.= "project=".$HTTP_GET_VARS["project"];
		}else
		{
			if($action=="insert")
				$backAddress= "index.php";
			else
				$backAddress= "list.php?table=$tableName";
		}
		$defaultBodyHead= getDefaultBodyHead($backAddress);
		$defaultBodyFoot= getDefaultBodyFoot();
			
		if($projectID)
		{
		 	// erstelle Tabelle MUSTable f�r die Auflistung,
			// sowie des h1-Tag, inden �berschrift kommt
			$statement= "select Name from MUProject where ID=$projectID";
			$projectName= $UserDb->fetch_single($statement);
				$center= new CenterTag();
  				$ueberschrift= new H1Tag();
  					$em= new EmTag();
  						$em->add("Projekt ");
  					$ueberschrift->add($em);
  					$ueberschrift->add($projectName);
  					$ueberschrift->add(br());
					$center->add($ueberschrift);
				$defaultBodyHead->add($center);
		}
				
				
				
			
			if($tableName=="MUUser")
			{				
				$MUSBox->select("UserName");
				$MUSBox->select("FullName", "voller Name");
				$MUSBox->select("EmailAddress", "E-Mail Adresse");
				$MUSBox->select("Description", "Beschreibung");
					
				$MUSBox->uniqueKey("UserName GroupType");				
				$MUSBox->onOKGotoUrl("list.php?table=$tableName&project=".$HTTP_GET_VARS["project"]);
				
				if($action=="insert")
				{
					$MUSBox->select("Pwd", "Passwort");
					$MUSBox->password('Pwd');
					$MUSBox->passwordNames("Passwort", "Eingabe wiederholen");
					$MUSBox->setAlso("GroupType", "custom");
					$MUSBox->setAlso("DateCreation", "sysdate()");
					$MUSBox->insert();
				}elseif($action=="aktualisieren")
				{
					$statement= "select GroupType from MUUser where ID=".$HTTP_GET_VARS["ID"];
					$GroupType= $UserDb->fetch_single($statement);
					if($GroupType=="custom")
					{
						$MUSBox->select("Pwd", "Passwort");
						$MUSBox->password('Pwd');
						$MUSBox->passwordNames("neues Passwort", "Eingabe wiederholen");
						
					}else
						$MUSBox->disabled("UserName");
					
					$MUSBox->where("ID=".$HTTP_GET_VARS["ID"]);
					$MUSBox->update();
				}
			}elseif($tableName=="MUGroup")
			{
				$columns=  "Name Bezeichnung";
				//$columns.= ",Description Beschreibung";
				$MUSBox->columns($columns);
				$MUSBox->onOKGotoUrl("list.php?table=$tableName&project=".$HTTP_GET_VARS["project"]);

				if($action=="insert")
				{
					$MUSBox->setAlso("DateCreation", "sysdate()");
					$MUSBox->insert();
				}elseif($action=="aktualisieren")
				{
					$MUSBox->where("ID=".$HTTP_GET_VARS["ID"]);
					$MUSBox->update();
				}
			}elseif($tableName=="MUCluster")
			{
				$columns=  "ID Cluster";
				$columns.= ",Description Beschreibung";
				//$columns.= ",addUser 'User zu den Gruppen hinzuf&uuml;gen'";
				//$columns.= ",addGroup 'Gruppen zu den Cluster hinzuf&uuml;gen'";				
				$MUSBox->columns($columns);
				$MUSBox->onOKGotoUrl("list.php?table=$tableName&project=".$HTTP_GET_VARS["project"]);
				if($action=="insert")
				{
					$MUSBox->setAlso("ProjectID", $projectID);
					$MUSBox->setAlso("DateCreation", "sysdate()");
					$MUSBox->insert();
				}elseif($action=="aktualisieren")
				{
					$MUSBox->where("ID='".$HTTP_GET_VARS["ID"]."'");
					$MUSBox->update();
				}
			}elseif($tableName=="MUProject")
			{
				$columns=  "Name ProjektName";
				$columns.= ",Path ProjektPfad";
				$columns.= ",Description Beschreibung";				
				$MUSBox->columns($columns);
				$join= "ProjectID=MUProject.Name";
				$MUSBox->join($join);
				$MUSBox->onOKGotoUrl("list.php?table=$tableName&project=".$HTTP_GET_VARS["project"]);
				if($action=="insert")
				{
					$MUSBox->setAlso("DateCreation", "sysdate()");
					$MUSBox->insert();
				}elseif($action=="aktualisieren")
				{
					$MUSBox->where("ID='".$HTTP_GET_VARS["ID"]."'");
					$MUSBox->update();
				}
			}
			
?>


<html>
		<? $head->display() ?>
		<body>
			<? $defaultBodyHead->display() ?>
			<br><br><br><br><br>
			<center>
				<? $MUSBox->display() ?>
			</center>
			<? $defaultBodyFoot->display() ?>
		</body>		
</html>