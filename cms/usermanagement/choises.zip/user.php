<?php


		require_once("head.php");
		require_once($table_out);
		require_once($php_htmltag_class);
		
		
				
				
		$statement= "select u.UserName,u.FullName as Name,u.GroupType as type";
		$statement.= " from MUUser as u inner join MUUserGroup as ug on ug.UserID=u.ID";
		$statement.= " inner join MUGroup as g on ug.GroupID=g.ID and g.Name='".$HTTP_GET_VARS["group"]."'";
		$MUSTable= new MUSTable($UserDb);
		$MUSTable->solution($statement);
		$MUSTable->execute();
		
			$title= "UserManagement";
			$head= makeHead($title);
				$head->add($MUSTable->getDefaultCssLink());

?>
<html>
		<? $head->display(); ?>
		<body>
			<center>
				<br />
				<br />
				<h1>User in der Gruppe <font color="red"><? echo $HTTP_GET_VARS["group"] ?></font></h1>
				<br />
				<br />
				<br />
				<br />
				<? $MUSTable->display(); ?>
		</body>		
</html>		