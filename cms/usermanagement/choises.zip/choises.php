<?php


		require_once("head.php");
	
			//f�r <HEAD>
			$title= "UserManagement";
			$head= makeHead($title);
			//f�r <BODY>
			$projectID= $HTTP_GET_VARS["project"];
			$backAddress= "index.php";
			$defaultBodyHead= getDefaultBodyHead($backAddress);
			$defaultBodyFoot= getDefaultBodyFoot();
			$statement= "select Name from MUProject where ID=$project";
			$projectName= $UserDb->fetch_single($statement);
			$statement= "select ID from MUCluster where ProjectID=$project";
			if($user->hasAccess("allAdmin") && $projectName=="UserManagement")
				$statement.= " or ID='allAdmin'";
			$clusterArr= $UserDb->fetch_single_array($statement);
			$Clusters= new DivTag();
			foreach($clusterArr as $cluster)
			{
				$tr= new RowTag();
					$td= new ColumnTag(TD);
					$tr->add($td);
					$td= new ColumnTag(TD);
						$td->align("center");
						$td->colspan(2);
  					$input= new InputTag();
    					$input->type("button");
    					$input->value($cluster);
  						$input->onClick("javascript:self.location='list.php?table=MUClusterGroup&project=$projectID&cluster=$cluster'");
						$td->add($input);
					$tr->add($td);
				$Clusters->add($tr);
			}
?>
<html>
		<? $head->display() ?>
		<body>
			<? $defaultBodyHead->display() ?>
			<br><br><br><br><br>
			<center>
				<h1>
					<em>Projekt</em>
					<? echo $projectName ?>
				</h1>
				<table border="1">
<?   // --  Cluster erstellen  -----------------------------------------------------------------------------
			if($user->hasAccess("allAdmin"))
			{ ?>
					<tr>
						<td align="right">
							<b>
								Cluster:
							</b>
						</td>
						<td>
							<input type="button" value="erstellen"
									onClick="javascript:self.location.href='make.php?action=insert&table=MUCluster&project=<? echo $projectID; ?>'" />
						</td>
						<td>
							<input type="button" value="aktualisieren/l�schen" 
									onclick="javascript:self.location.href='list.php?table=MUCluster&project=<? echo $projectID; ?>'" />
						</td>
					</tr>
		<?	}
	 // --  Gruppenzuordnungen zu den Clustern  ------------------------------------------------------------
				   if($user->hasUserManagementAccess($ProjectID, addGroup))
				   { ?>
					<tr>
						<th align="center" colspan=3>
							Gruppenzuordnungen zu den projektspezifischen Clustern:
						</th>
					</tr>
					<? $Clusters->display(); 
				   }
	 // --  Userzuordnungen zu den Gruppen  --------------------------------------------------------------- 
				   if($user->hasUserManagementAccess($ProjectID, addUser))
				   { ?>
					<tr>
						<td align="right">
							<b>
								Userzuordnungen zu den Gruppen:
							</b>
						</td>
						<td colspan="2" align="center">
							<input type="button" value="hinzuf�gen/entfernen" 
									onclick="javascript:self.location.href='list.php?table=MUUserGroup&project=<? echo $projectID; ?>'" />
						</td>
					</tr>
				<? } ?>
				</table>		
			</center>
			<? $defaultBodyFoot->display() ?>
		</body>		
</html>