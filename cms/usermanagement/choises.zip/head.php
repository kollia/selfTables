<?PHP

  	require_once("tools_path.php");
		//require_once($php_tools);
		require_once($php_htmltag_class);
  	// Zugriffs-Berechtigung setzen
  	require_once($user_property);
		//$user->debug(true); 
  	$user->verifyLogin("UserManagement");
  	//Tag::debug(true);
		
  	// eigene Datenbank aufbauen	
  	//$connection= new MUSDatabase();
  	//$connection->connect("pw02zpr010", "medienarch", "archiv");
  	//$connection->toDatabase("Protokolle");
  	// ##hier im Bsp. wird nur auf $UserDb zugegriffen
  	// ##welche schon in $user_property("mug/my_inc_user_check.php") deffiniert wird
  	
		
	// erzeuge standard head-tags
		function makeHead($title)
		{
			$head= new HeadTag();
  			$htitle= new TitleTag($title);
				$head->add($htitle);
			return $head;
		}
	// erzeuge standard body description f�r Anfang und Ende
		function getDefaultBodyHead($backAddress= null)
		{
			global $user;
			
			$div= new DivTag();				
				$table= new TableTag();
					$table->width('100%');
					$tr= new RowTag();						
						$td= new ColumnTag(TD);
							$td->align("right");	
			//if($user->mustRegister())						
			//				$td->add($user->getLogoutButton("Logout"));	
			if($backAddress)
			{					
							$td->add(br());		
							$input= new InputTag();
								$input->type("button");
								$input->value("zur�ck");
								$input->onClick("javascript:self.location.href='$backAddress'");
							$td->add($input);	
			}
						$tr->add($td);
					$table->add($tr);
				$div->add($table);
			
			return $div;
		}
		function getDefaultBodyFoot()
		{
			$div= new DivTag();
			return $div;
		}
	
?>