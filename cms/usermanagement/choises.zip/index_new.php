<?php


	$db= new MUSDatabase("UserManagement");
	$db->connect("localhost", "usermanagement", "hupfauf");
	$db->useDatabase("UserManagement");
	
	$userManagement= &new STUserManagementContainer($db);
	
	$side= &new MUSDbSiteCreator(3/*UserManagement*/, $userManagement);
	$side->execute();
	$side->display();
	
	
?>