<?php

		require_once("head.php");
		require_once($table_out);
		require_once($php_htmltag_class);

//Tag::debug(true);				
		function groupCallback(&$oTable, $columnName, $rownum)
		{
			if(preg_match("/^LKHGraz_/", $oTable->sqlResult[$rownum][$columnName]))
				$oTable->namedLink();
		} 
		function descriptionCallback(&$oTable, $columnName, $rownum)
		{//print_r($oTable->sqlResult[$rownum]);
			//$oTable->echoResult();
			//echo "file:".__file__." line:".__line__."<br />";
			if($oTable->sqlResult[$rownum]["ID"]==1)
			{
				$aResult=	array(	"Name"=>"",
									"Description"=>"Zugriff auf alle Projekte und Untergruppen "	);
				$aResult= array($aResult);// es wird eine Zeile vorget�uscht
			}else
			{
				if($columnName=="Berechtigungen")
					$idColumn= "GID";
				else
					$idColumn= "ID";//echo $idColumn." is ".$oTable->sqlResult[$rownum][$idColumn];
  			$statement=  "select p.Name,c.Description from MUProject as p";
  			$statement.= " inner join MUCluster as c on p.ID=c.ProjectID";
  			$statement.= " inner join MUClusterGroup as cg on c.ID=cg.ClusterID";
  			$statement.= " where cg.GroupID=".$oTable->sqlResult[$rownum][$idColumn];
  			$statement.= " order by p.Name";
  			$aResult= $oTable->db->fetch_array($statement, MYSQL_ASSOC);
			}
			$source=   "<table>";
			foreach($aResult as $row)
			{				
				$source.=  "	<tr>";
				$source.=  "		<td>";
				$source.=  "			<b>";
				$source.=  "				[".$row["Name"]."]";
				$source.=  "			</b>";
				$source.=  "		</td>";
  			$source.=  "		<td>";
				$source.=  "				".$row["Description"];
  			$source.=  "		</td>";
  			$source.=  "	</tr>";  			
			}
			$source.=  "</table>";
			$oTable->sqlResult[$rownum][$columnName]= $source;
		}
		function changeCallback(&$oTable, $columnName, $rownum)
		{//print_r($oTable->sqlResult[$rownum]); echo "<br />";
			if($oTable->sqlResult[$rownum]["gruppe"]!="custom")
			{
				$oTable->sqlResult[$rownum][$columnName]= null;
				$oTable->noShowType();
			}
		}
		
		 	$projectID= $HTTP_GET_VARS["project"];
			if(!$projectID)
				$projectID= 0;
		 	$MUSTable= new MUSTable($UserDb);	
			// deffiniere <HEAD> und <BODY> mit allen Scripting-Tags
			$title= "UserManagement";
			$head= makeHead($title);
				$JavaScriptSrc= getJavaScriptTag("skripts/user_scripts.js");
				$head->add($JavaScriptSrc);
				$head->add($MUSTable->getDefaultCssLink());
			//f�r <BODY>
			if(!isset($HTTP_GET_VARS["onlyOne"]))
			{
				if(	$user->hasAccess("allAdmin")
					and
					$projectID					)
				{
					$backAddress= "choises.php?project=$projectID";
				}else
					$backAddress= "index.php";
			}
			$defaultBodyHead= getDefaultBodyHead($backAddress);
			
		if($projectID)
		{
		 	// erstelle Tabelle MUSTable f�r die Auflistung,
			// sowie des h1-Tag, inden �berschrift kommt
			$statement= "select Name from MUProject where ID=$projectID";
			$projectName= $UserDb->fetch_single($statement);
				$center= new CenterTag();
  				$ueberschrift= new H1Tag();
  					$em= new EmTag();
  						$em->add("Projekt ");
  					$ueberschrift->add($em);
  					$ueberschrift->add($projectName);
  					$ueberschrift->add(br());
					$center->add($ueberschrift);
				$defaultBodyHead->add($center);
		}
  			
    		
			$JavaScript= getJavaScriptTag();
			// Statement erzeugen f�r spezifische Tabelle
		 	$tableName= $HTTP_GET_VARS["table"];
			if($tableName=="MUProject")
			{
				$center= new CenterTag();
					$ueberschrift= new H2Tag();
						$ueberschrift->add("Auflistung aller Projekte");
					$center->add($ueberschrift);
				$defaultBodyHead->add($center);
				if($HTTP_GET_VARS["action"]=="delete")
				{
					$ID= $HTTP_GET_VARS["ID"];
					$statement= "delete from $tableName where ID='$ID'";
					$delete= $UserDb->solution($statement);
					if($delete)
						$JavaScript->add("javascript:alert('Der Cluster $ID wurde erfolgreich gel�scht')");
					else
						$JavaScript->add("javascript:alert('Der Cluster $ID konnte nicht gel�scht werden')");
				}
				$statement= "select ID,Name Projekt, Path Pfad, Description Beschreibung";
				$statement.= ",ID as 'aktualisieren', ID as 'l&ouml;schen'";
				$statement.= " from $tableName order by ID";
				$MUSTable->address("javascript:field('%NAME%','$tableName','%VALUE%',$projectID)");
				
			}elseif($tableName=="MUCluster")
			{
				$center= new CenterTag();
					$ueberschrift= new H2Tag();
						$ueberschrift->add("Auflistung aller Cluster");
					$center->add($ueberschrift);
				$defaultBodyHead->add($center);
				if($HTTP_GET_VARS["action"]=="delete")
				{
					$ID= $HTTP_GET_VARS["ID"];
					$statement= "delete from $tableName where ID='$ID'";
					$delete= $UserDb->solution($statement);
					if($delete)
						$JavaScript->add("javascript:alert('Der Cluster $ID wurde erfolgreich gel�scht')");
					else
						$JavaScript->add("javascript:alert('Der Cluster $ID konnte nicht gel�scht werden')");
				}
				$statement= "select c.ID Cluster, p.Name Projekt, c.addUser 'User zu Gruppen'";
				$statement.= ", c.addGroup 'Gruppen zu Cluster', c.Description Beschreibung";
				$statement.= ", c.ID as 'aktualisieren', c.ID as 'l&ouml;schen'";
				$statement.= " from $tableName as c, MUProject as p";
				$statement.= " where c.ProjectID=p.ID and p.ID=$projectID order by c.ProjectID, c.addUser, c.addGroup";
				$MUSTable->address("javascript:field('%NAME%','$tableName','%VALUE%',$projectID)");
				
			}elseif($tableName=="MUUser")
			{
				$center= new CenterTag();
					$ueberschrift= new H2Tag();
						$ueberschrift->add("Auflistung aller User");
					$center->add($ueberschrift);
				$defaultBodyHead->add($center);
				if($HTTP_GET_VARS["action"]=="delete")
				{
					$statement= "select UserName,FullName from $tableName where ID=".$HTTP_GET_VARS["ID"];
					$row= $UserDb->fetch_row($statement);
					$UserName= $row[0];
					$FullName= $row[1];
					$statement= "delete from $tableName where ID=".$HTTP_GET_VARS["ID"];
					$delete= $UserDb->solution($statement);
					if($delete)
						$JavaScript->add("javascript:alert('Der User $UserName($FullName) wurde erfolgreich gel�scht')");
					else
						$JavaScript->add("javascript:alert('Der User $UserName($FullName) konnte nicht gel�scht werden')");
				}
				$statement= "select GroupType gruppe, UserName, FullName 'Name', ";
				$statement.= "EmailAddress 'E-Mail', LastLogin 'letzter Login', NrLogin login,";
				$statement.= "ID as 'aktualisieren', ID as 'l&ouml;schen' from $tableName";
				$statement.= " order by GroupType, UserName";
				$MUSTable->address("javascript:field('%NAME%','$tableName',%VALUE%,$projectID)");
				//$MUSTable->callback("aktualisieren", "changeCallback");
				$MUSTable->callback("l&ouml;schen", "changeCallback");
				
			}elseif($tableName=="MUUserGroup")
			{
				$center= new CenterTag();
					$ueberschrift= new H2Tag();
						$ueberschrift->add("Zugeh�rigkeiten der User zu den Gruppen");
					$center->add($ueberschrift);
				$defaultBodyHead->add($center);
				
				// selectiere alle User f�r die Auswahl
				$statement= "select ID, concat_ws(' - ',GroupType,UserName,FullName) from MUUser";
				$statement.= " order by GroupType, UserName, FullName";
				$users= $UserDb->fetch_array($statement);
				$html= new GetHtml();//Objekt in dem der SelectTag erstellt wird
				$UserID= $HTTP_POST_VARS["UserID"];
				if(!isset($UserID))
					$UserID= $users[0][0];
				
				$form= new FormTag();
					$form->method("post");	
					$center= new CenterTag();
						$b= new BTag();
							$b->add("User:");
						$center->add($b);
						$select= $html->getSelectArray($users, 0, 1, $UserID);
							$select->name("UserID");
							$select->onChange("javascript:submit()");
						$center->add($select);
					$center->add($description);
					$form->add($center);
				$defaultBodyHead->add($form);
				
				// dann erzeuge das Statement f�r die solution
				$statement=  "select distinct ug.ID 'UGID', g.ID 'GID', g.Name Gruppenname";
				$statement.= ", ug.ID 'YesNo',c.Description 'Berechtigungen',ug.DateCreation 'Zugeh&ouml;rigkeit seit'";
				$statement.= " from MUGroup as g";
				$statement.= " inner join MUClusterGroup as cg on g.ID=cg.GroupID and g.Name!='LOGGED_IN'";
				$statement.= " and g.Name not like 'LKHGraz_%'";
				$statement.= " inner join MUCluster as c on cg.ClusterID=c.ID and ";
				if($user->hasAccess("allAdmin") && $projectName=="UserManagement")
					$statement.= "(";
				$statement.= "c.ProjectID=$projectID";
				if($user->hasAccess("allAdmin") && $projectName=="UserManagement")
					$statement.= " or c.ID='allAdmin')";
				$statement.= " left join MUUserGroup as ug on g.ID=ug.GroupID and ug.UserID=$UserID";//u.ID=ug.UserID and 
				$statement.= " order by g.Name";
				$MUSTable->form("speichern", "checkForm");
				$MUSTable->hidden("UserID", $UserID);
				$MUSTable->insert("insert into MUUserGroup values(0,$UserID,%GID%,sysdate())");
				$MUSTable->delete("delete from MUUserGroup where ID=%UGID%");
				//$MUSTable->address("javascript:field('%NAME%','$tableName',%VALUE%,$projectID)");
				$MUSTable->getColumn("UGID");
				$MUSTable->getColumn("GID");
				$MUSTable->checkBoxes("YesNo");
				$MUSTable->callback("Berechtigungen", "descriptionCallback");
				$secondTable = new MUSTable($UserDb);
				$stat2= "select g.Name from MUGroup as g,MUUserGroup as u";
				$stat2.= " where u.UserID=".$UserID;
				$stat2.= " and g.Name like 'LKHGraz_%'";
				$stat2.= " and u.GroupID=g.ID";
				$secondTable->solution($stat2);
				$secondTable->execute(noErrorShow);
			}elseif($tableName=="MUGroup")
			{
				$center= new CenterTag();
					$ueberschrift= new H2Tag();
						$ueberschrift->add("Auflistung aller Gruppen");
					$center->add($ueberschrift);
				$defaultBodyHead->add($center);
				
				if($HTTP_GET_VARS["action"]=="delete")
				{
					$statement= "select Name from $tableName where ID=".$HTTP_GET_VARS["ID"];
					$name= $UserDb->fetch_single($statement);
					$statement= "delete from $tableName where ID=".$HTTP_GET_VARS["ID"];
					$delete= $UserDb->solution($statement);
					if($delete)
						$JavaScript->add("javascript:alert('Die Gruppe $name wurde erfolgreich gel�scht')");
					else
						$JavaScript->add("javascript:alert('Die Gruppe $name konnte nicht gel�scht werden')");
				}
				$statement=  "select g.ID,g.Name Gruppenbezeichnung,g.Description Beschreibung,";
				$statement.= "g.ID as 'aktualisieren', g.ID as 'l&ouml;schen'";
				$statement.= " from $tableName as g where g.Name not like 'LKHGraz_%' and g.Name!='LOGGED_IN'";
				$MUSTable->address("javascript:field('%NAME%','$tableName',%VALUE%,$projectID)");
				$MUSTable->callback("Beschreibung", "descriptionCallback");
			}elseif($tableName=="MUClusterGroup")
			{
				$clusterName= $HTTP_GET_VARS["cluster"];
				$center= new CenterTag();
					$ueberschrift= new H2Tag();
						$ueberschrift->add("Zugeh�rigkeit der Gruppen zum Cluster ");
    				$em= new EmTag();
    					$font= new FontTag();
    						$font->add($clusterName);
    						$font->color("red");
    					$em->add($font);
    				$ueberschrift->add($em);
					$center->add($ueberschrift);
				$statement= "select Description from MUCluster where ID='$clusterName'";
				$description= $UserDb->fetch_single($statement);
					$center->add($description);
					$center->add(br());
					$center->add(br());
				$defaultBodyHead->add($center);
				$clusterName= $HTTP_GET_VARS["cluster"];

				if(!$user->hasAccess("allAdmin") && $clusterName!="UserManagement")
				{
  				// selectiere aus der Datenbank alle Gruppen die auf den Cluster 'allAdmin' zugriff haben,
  				// diese sollen nicht angezeigt werden
  				$statement=  "select g.Name from MUGroup as g, MUClusterGroup as cg";
  				$statement.= " where cg.GroupID=g.ID and cg.ClusterID='allAdmin'";
  				$admins= $UserDb->fetch_single_array($statement);
				}
				// dann erzeuge das Statement f�r die solution
				$statement=  "select distinct g.ID 'GID',cg.ID 'CGID'";
				$statement.= ",g.Name Gruppe,cg.ID 'YesNo',cg.DateCreation 'Zugeh&ouml;rigkeit seit'";
				$statement.= " from MUGroup as g";
				$statement.= " left join MUClusterGroup as cg on g.ID=cg.GroupID and cg.ClusterID='$clusterName'";
				if($admins)
					foreach($admins as $admin)
						$statement.= " and g.Name!='$admin'";
				$statement.= " order by g.Name";
				$MUSTable->form("speichern", "checkForm");
				$MUSTable->insert("insert into MUClusterGroup values(0,'$clusterName',%GID%,sysdate())");
				$MUSTable->delete("delete from MUClusterGroup where ID=%CGID%");
				$MUSTable->setMessageContent("EMPTY_RESULT", "es ist kein Cluster f�r dieses Projekt angelegt");
				$MUSTable->getColumn("GID");
				$MUSTable->getColumn("CGID");				
				$MUSTable->callback("Gruppe", "groupCallback");
				$MUSTable->checkBoxes("YesNo");
				$MUSTable->address("javascript:field('%NAME%','$tableName','%VALUE%',$projectID)");
				
			}

			$MUSTable->solution($statement);
  		$MUSTable->link("aktualisieren");
  		$MUSTable->link("l&ouml;schen");
			$MUSTable->execute(noErrorShow);
				
			
?>


<html>
		<? $head->display() ?>
		<body>
			<? $defaultBodyHead->display() ?>
			<center>
				<? $MUSTable->display() ?>
<?	if($secondTable)
		{	?>
				<br />
				<br />
				<br />
				<h3>
					zugeh�rigkeit zu den externen Gruppen
				</h3>
<?			$secondTable->display();
		}	?>
			</center>
			<? $JavaScript->display() ?>
		</body>		
</html>			
		