<?php


	require_once("STForum.php");
	
	//Tag::debug("forum");
	$forum= new STForum($siteCreator);
	$forum->execute();
	
						 
?>